import UIKit

class CartTableViewCell: UITableViewCell {
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var price: UILabel!
}
