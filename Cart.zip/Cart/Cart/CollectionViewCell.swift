//
//  CollectionViewCell.swift
//  Cart
//
//  Created by Sreelekshmi S on 30/06/17.
//  Copyright © 2017 Sreelekshmi S. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var moreImages: UIImageView!
}
