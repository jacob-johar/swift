import Foundation
class Products{
    var pID:String="P00"
    var pName:String="No Name"
    var pPrice:Int=0
    var pQuantity:Int=1
    var pDescriton:String="No description"
    var imageList:[String]=["q3"]
}
